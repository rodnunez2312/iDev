def Viajes():
    viajes = {
        {
            'id': 1,
            'title':'Article One',
            'body':'this is the body',
            'author':'Rod Sanchez',
            'created date':'07-18-2019'
        },
        {
            'id': 2,
            'title':'Article Dos',
            'body':'this is the body',
            'author':'Mar Sanchez',
            'created date':'07-18-2019'
        },
        {
            'id': 3,
            'title':'Article Tres',
            'body':'this is the body',
            'author':'Rod Sanchez',
            'created date':'07-18-2019'
        },

    }
   return viajes